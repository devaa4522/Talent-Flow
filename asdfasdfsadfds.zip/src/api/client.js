import { API } from "../lib/api";
export default API;
