console.log('Reset seed is a no-op in Node. To reset local data, clear IndexedDB for this site in your browser (Application > Storage).');
