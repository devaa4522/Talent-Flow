import { rest } from 'msw';
import { db } from '../db';
import { withLatency, shouldFail } from '../utils/latency';
import { paginate } from '../utils/pagination';
import { slugify } from '../utils/slugify';

function parseBool(v) { return v === 'true' || v === true; }

export const handlers = [
  // --- JOBS ---
  rest.get('/jobs', async (req, res, ctx) => {
    const search = req.url.searchParams.get('search') || '';
    const status = req.url.searchParams.get('status') || '';
      const tags = (req.url.searchParams.get('tags') || '').split(',').map(t=>t.trim()).filter(Boolean);
    const page = parseInt(req.url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(req.url.searchParams.get('pageSize') || '10', 10);
    const sort = req.url.searchParams.get('sort') || 'order';

    const all = await db.jobs.toArray();
    let filtered = all.filter(j => 
      (!status || j.status === status) &&
      (!search || j.title.toLowerCase().includes(search.toLowerCase()))
    );
    if (sort === 'order') filtered.sort((a,b) => a.order - b.order);
    if (sort === 'title') filtered.sort((a,b) => a.title.localeCompare(b.title));
    const result = paginate(filtered, page, pageSize);
    return withLatency(() => res(
      ctx.status(200),
      ctx.json(result)
    ));
  }),

  rest.get('/jobs/:id', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const job = await db.jobs.get(id);
    if (!job) return res(ctx.status(404));
    return withLatency(() => res(ctx.json(job)));
  }),

  rest.post('/jobs', async (req, res, ctx) => {
    const body = await req.json();
    const title = (body.title || '').trim();
    if (!title) return withLatency(() => res(ctx.status(400), ctx.text('Title is required')));
    const slug = body.slug ? slugify(body.slug) : slugify(title);
    const exists = await db.jobs.where('slug').equals(slug).first();
    if (exists) return withLatency(() => res(ctx.status(409), ctx.text('Slug must be unique')));
    const count = await db.jobs.count();
    const job = { id: count + 1, title, slug, status: 'active', tags: body.tags || [], order: count };
    if (shouldFail(0.08)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
    await db.jobs.put(job);
    return withLatency(() => res(ctx.status(201), ctx.json(job)));
  }),

  rest.patch('/jobs/:id', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const patch = await req.json();
    const job = await db.jobs.get(id);
    if (!job) return withLatency(() => res(ctx.status(404), ctx.text('Not found')));
    if (patch.slug) {
      const slug = slugify(patch.slug);
      const exists = await db.jobs.where('slug').equals(slug).first();
      if (exists && exists.id !== id) return withLatency(() => res(ctx.status(409), ctx.text('Slug must be unique')));
      patch.slug = slug;
    }
    if (shouldFail(0.08)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
    const updated = { ...job, ...patch };
    await db.jobs.put(updated);
    return withLatency(() => res(ctx.json(updated)));
  }),

  rest.patch('/jobs/:id/reorder', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const body = await req.json();
    const { fromOrder, toOrder } = body;
    // Occasionally return 500 to test rollback
    if (Math.random() < 0.15) {
      return withLatency(() => res(ctx.status(500), ctx.text('Reorder failed randomly')));
    }
    const jobs = await db.jobs.orderBy('order').toArray();
    const moved = jobs.find(j => j.id === id);
    if (!moved) return withLatency(() => res(ctx.status(404), ctx.text('Not found')));
    // Reorder
    jobs.splice(fromOrder, 1);
    jobs.splice(toOrder, 0, moved);
    for (let i=0;i<jobs.length;i++) jobs[i].order = i;
    await db.jobs.bulkPut(jobs);
    return withLatency(() => res(ctx.status(200), ctx.json({ ok:true })));
  }),

  // --- CANDIDATES ---
    rest.post('/candidates', async (req, res, ctx) => {
      const body = await req.json();
      if (!body.name || !body.email) return withLatency(() => res(ctx.status(400), ctx.text('name and email required')));
      const id = (await db.candidates.count()) + 1;
      const candidate = { id, name: body.name, email: body.email, jobId: body.jobId || null, stage: body.stage || 'applied' };
      if (shouldFail(0.08)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
      await db.candidates.put(candidate);
      await db.candidateTimelines.add({ candidateId: id, at: new Date().toISOString(), from: 'applied', to: candidate.stage, note: 'Applied' });
      return withLatency(() => res(ctx.status(201), ctx.json(candidate)));
    }),
    
  rest.get('/candidates', async (req, res, ctx) => {
    const search = req.url.searchParams.get('search') || '';
    const stage = req.url.searchParams.get('stage') || '';
    const page = parseInt(req.url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(req.url.searchParams.get('pageSize') || '50', 10);

    let all = await db.candidates.toArray();
    if (search) {
      const s = search.toLowerCase();
      all = all.filter(c => c.name.toLowerCase().includes(s) || c.email.toLowerCase().includes(s));
    }
    if (stage) all = all.filter(c => c.stage === stage);
    const result = paginate(all, page, pageSize);
    return withLatency(() => res(ctx.json(result)));
  }),

  rest.get('/candidates/:id', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const c = await db.candidates.get(id);
    if (!c) return withLatency(() => res(ctx.status(404)));
    return withLatency(() => res(ctx.json(c)));
  }),

  rest.patch('/candidates/:id', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const patch = await req.json();
    const c = await db.candidates.get(id);
    if (!c) return withLatency(() => res(ctx.status(404)));
    if (shouldFail(0.1)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
    const updated = { ...c, ...patch };
    await db.candidates.put(updated);
    if (patch.stage && patch.stage !== c.stage) {
      await db.candidateTimelines.add({
        candidateId: id,
        at: new Date().toISOString(),
        from: c.stage, to: patch.stage,
        note: 'Stage change'
      });
    }
    return withLatency(() => res(ctx.json(updated)));
  }),

  rest.get('/candidates/:id/timeline', async (req, res, ctx) => {
    const id = Number(req.params.id);
    const events = await db.candidateTimelines.where('candidateId').equals(id).toArray();
    events.sort((a,b) => new Date(a.at) - new Date(b.at));
    return withLatency(() => res(ctx.json(events)));
  }),

  // --- ASSESSMENTS ---
  rest.get('/assessments/:jobId', async (req, res, ctx) => {
    const jobId = Number(req.params.jobId);
    const doc = await db.assessments.get(jobId);
    if (!doc) return withLatency(() => res(ctx.status(404), ctx.text('Not found')));
    return withLatency(() => res(ctx.json(doc)));
  }),

  rest.put('/assessments/:jobId', async (req, res, ctx) => {
    const jobId = Number(req.params.jobId);
    const payload = await req.json();
    if (shouldFail(0.08)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
    await db.assessments.put({ jobId, ...payload, updatedAt: new Date().toISOString() });
    return withLatency(() => res(ctx.json({ ok:true })));
  }),

  rest.post('/assessments/:jobId/submit', async (req, res, ctx) => {
    const jobId = Number(req.params.jobId);
    const answers = await req.json();
    if (shouldFail(0.08)) return withLatency(() => res(ctx.status(500), ctx.text('Random failure')));
    await db.assessmentSubmissions.add({
      jobId, candidateId: answers.candidateId || null, submittedAt: new Date().toISOString(), answers
    });
    return withLatency(() => res(ctx.json({ ok:true })));
  }),
];
