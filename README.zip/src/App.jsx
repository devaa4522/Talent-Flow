import React, { useEffect } from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { Routes, Route, NavLink } from 'react-router-dom';
import JobsPage from './pages/JobsPage';
import CandidatesPage from './pages/CandidatesPage';
// import TalentflowPage from './pages/TalentflowPage';
import CandidateProfilePage from './pages/CandidateProfilePage';
import JobDetailPage from './pages/JobDetailPage';
import AssessmentsPage from './pages/AssessmentsPage';
import { seedIfEmpty } from './seed';

export function App() {
  useEffect(() => {
    seedIfEmpty();
  }, []);

  return (
    <div className="app-shell">
      <Navbar bg="light" expand="lg" className="mb-3 border-bottom">
        <Container>
          <Navbar.Brand as={NavLink} to="/">TalentFlow</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link as={NavLink} to="/jobs">Jobs</Nav.Link>
              <Nav.Link as={NavLink} to="/candidates">Candidates</Nav.Link>
              <Nav.Link as={NavLink} to="/assessments">Assessments</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Container className="pb-5">
        <Routes>
          <Route index element={<JobsPage />} />
          <Route path="/jobs" element={<JobsPage />} />
          {/* <Route path="/talentflow" element={<TalentflowPage />} /> */}
          <Route path="/jobs/:jobId" element={<JobDetailPage />} />
          <Route path="/candidates" element={<CandidatesPage />} />
          <Route path="/candidates/:id" element={<CandidateProfilePage />} />
          <Route path="/assessments" element={<AssessmentsPage />} />
        </Routes>
      </Container>
    </div>
  );
}
