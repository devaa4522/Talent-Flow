import Dexie from 'dexie';

export const db = new Dexie('talentflow');
db.version(1).stores({
  jobs: '++id, slug, status, order, title, tags',
  candidates: '++id, email, name, jobId, stage',
  candidateTimelines: '++id, candidateId, at',
  assessments: 'jobId',
  assessmentSubmissions: '++id, jobId, candidateId'
});

export async function resetDB() {
  await db.delete();
  await db.open();
}
