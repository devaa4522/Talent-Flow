
import { db } from './db';
import { slugify } from './utils/slugify';

const STAGES = ["applied","screen","tech","offer","hired","rejected"];
const TAGS = ["remote","hybrid","onsite","contract","full-time","urgent","senior","junior"];

function rnd(arr) { return arr[Math.floor(Math.random()*arr.length)]; }
function name() {
  const f = ["Alex","Sam","Jordan","Taylor","Riley","Jamie","Casey","Avery","Morgan","Drew","Skyler","Parker","Lee","Quinn","Blake","Reese","Shawn","Aiden","Noah","Mia","Liam","Zoe"];
  const l = ["Patel","Singh","Khan","Iyer","Shah","Gupta","Das","Fernandes","Roy","Mehta","Nair","Kapoor","Reddy","Chowdhury","Bose","Mukherjee","Joshi","Bhat","Shetty","Desai"];
  return `${rnd(f)} ${rnd(l)}`;
}
function jobTitle() {
  const roles = ["Frontend Engineer","Backend Engineer","Fullstack Developer","QA Engineer","Data Analyst","Product Manager","UI/UX Designer","DevOps Engineer","ML Engineer","Support Engineer"];
  const seniorities = ["Junior","Mid","Senior","Lead"];
  return `${rnd(seniorities)} ${rnd(roles)}`;
}

async function seedJobs() {
  const count = await db.jobs.count();
  if (count > 0) return;

  const jobs = Array.from({length:25}).map((_,i) => {
    const title = jobTitle();
    const slug = slugify(title + '-' + (i+1));
    const status = Math.random() < 0.2 ? 'archived' : 'active';
    const tags = Array.from(new Set([rnd(TAGS), rnd(TAGS), rnd(TAGS)])).slice(0,2);
    return { id: i+1, title, slug, status, tags, order: i };
  });
  await db.jobs.bulkPut(jobs);
}

function emailFrom(n) {
  const [first, last] = n.toLowerCase().split(' ');
  return `${first}.${last}${Math.floor(Math.random()*1000)}@example.com`;
}

async function seedCandidates() {
  const count = await db.candidates.count();
  if (count > 0) return;
  const jobs = await db.jobs.toArray();
  const candidates = [];
  let id = 1;
  for (let i=0; i<1000; i++) {
    const nm = name();
    const stage = rnd(STAGES);
    const job = rnd(jobs);
    candidates.push({ id: id, name: nm, email: emailFrom(nm), jobId: job.id, stage });
    id++;
  }
  await db.candidates.bulkPut(candidates);

  const timelines = [];
  for (const c of await db.candidates.toArray()) {
    const transitions = Math.floor(Math.random() * 3) + 1;
    let current = "applied";
    const now = Date.now();
    for (let i=0;i<transitions;i++) {
      const to = rnd(STAGES);
      timelines.push({ candidateId: c.id, at: new Date(now - (transitions-i)*86400000).toISOString(), from: current, to, note: '' });
      current = to;
    }
  }
  await db.candidateTimelines.bulkPut(timelines);
}

async function seedAssessments() {
  const count = await db.assessments.count();
  if (count > 0) return;
  const jobs = await db.jobs.limit(3).toArray();
  for (const job of jobs) {
    await db.assessments.put({
      jobId: job.id,
      updatedAt: new Date().toISOString(),
      sections: [
        {
          id: 'sec-1',
          title: 'Basics',
          questions: [
            { id:'q1', type:'single', label:'Are you willing to work remotely?', required:true, options:['Yes','No'] },
            { id:'q2', type:'text', label:'Briefly introduce yourself', required:true, maxLength: 200 },
            { id:'q3', type:'number', label:'Years of experience', required:true, min:0, max:40 },
            { id:'q4', type:'multi', label:'Which frontend libs have you used?', options:['React','Vue','Angular','Svelte'] },
            { id:'q5', type:'long', label:'Tell us about a challenging bug you fixed', maxLength: 500 },
            { id:'q6', type:'file', label:'Upload a portfolio PDF (stub)' },
            { id:'q7', type:'text', label:'GitHub username', required:false, showIf:{ questionId:'q1', equals:'Yes' } }
          ]
        }
      ]
    });
  }
}

export async function seedIfEmpty() {
  await seedJobs();
  await seedCandidates();
  await seedAssessments();
}
