import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import API from '../api/client';
import { Button, Form, InputGroup } from 'react-bootstrap';

const TYPES = [
  { id:'single', label:'Single choice' },
  { id:'multi', label:'Multi choice' },
  { id:'text', label:'Short text' },
  { id:'long', label:'Long text' },
  { id:'number', label:'Numeric' },
  { id:'file', label:'File upload (stub)' },
];

function useQuery() {
  const { search } = useLocation();
  return useMemo(() => Object.fromEntries(new URLSearchParams(search).entries()), [search]);
}

function QuestionEditor({ q, onChange, onRemove, index, allQuestions }) {
  return (
    <div className="question-item">
      <div className="d-flex justify-content-between align-items-center">
        <strong>Q{index+1}</strong>
        <div className="d-flex gap-2">
          <Button size="sm" variant="outline-danger" onClick={onRemove}>Remove</Button>
        </div>
      </div>
      <div className="row g-2 mt-1">
        <div className="col-md-4">
          <label className="form-label">Type</label>
          <select className="form-select" value={q.type} onChange={e=>onChange({ ...q, type:e.target.value })}>
            {TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
        </div>
        <div className="col-md-8">
          <label className="form-label">Label</label>
          <input className="form-control" value={q.label} onChange={e=>onChange({ ...q, label:e.target.value })} />
        </div>
      </div>
      {(q.type === 'single' || q.type === 'multi') && (
        <div className="mt-2">
          <label className="form-label">Options (comma-separated)</label>
          <input className="form-control" value={(q.options||[]).join(', ')} onChange={e=>onChange({ ...q, options: e.target.value.split(',').map(x=>x.trim()).filter(Boolean) })} />
        </div>
      )}
      {q.type === 'number' && (
        <div className="row g-2 mt-2">
          <div className="col-md-6"><input type="number" className="form-control" placeholder="Min" value={q.min ?? ''} onChange={e=>onChange({ ...q, min: e.target.value===''? undefined : Number(e.target.value) })} /></div>
          <div className="col-md-6"><input type="number" className="form-control" placeholder="Max" value={q.max ?? ''} onChange={e=>onChange({ ...q, max: e.target.value===''? undefined : Number(e.target.value) })} /></div>
        </div>
      )}
      <div className="row g-2 mt-2">
        <div className="col-md-4 d-flex align-items-center gap-2">
          <input type="checkbox" className="form-check-input" checked={!!q.required} onChange={e=>onChange({ ...q, required: e.target.checked })} />
          <label className="form-check-label">Required</label>
        </div>
        <div className="col-md-4">
          <input type="number" className="form-control" placeholder="Max length" value={q.maxLength ?? ''} onChange={e=>onChange({ ...q, maxLength: e.target.value===''? undefined : Number(e.target.value) })} />
        </div>
      </div>
      <div className="mt-2">
        <label className="form-label">Conditional (show if)</label>
        <div className="row g-2">
          <div className="col-md-5">
            <select className="form-select" value={q.showIf?.questionId || ''} onChange={e=>onChange({ ...q, showIf: { ...(q.showIf||{}), questionId: e.target.value || undefined } })}>
              <option value="">No condition</option>
              {allQuestions.filter(x=>x.id!==q.id).map(x => <option key={x.id} value={x.id}>{x.label || x.id}</option>)}
            </select>
          </div>
          <div className="col-md-3">
            <input className="form-control" placeholder="Equals" value={q.showIf?.equals || ''} onChange={e=>onChange({ ...q, showIf: { ...(q.showIf||{}), equals: e.target.value } })} />
          </div>
        </div>
      </div>
    </div>
  );
}

function AssessmentPreview({ sections, onSubmit }) {
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});

  function isVisible(q) {
    if (!q.showIf || !q.showIf.questionId) return true;
    const val = values[q.showIf.questionId];
    return String(val ?? '') === String(q.showIf.equals ?? '');
  }

  function validate() {
    const errs = {};
    for (const s of sections) {
      for (const q of s.questions) {
        if (!isVisible(q)) continue;
        const v = values[q.id];
        if (q.required && (v === undefined || v === '' || (Array.isArray(v) && v.length===0))) {
          errs[q.id] = 'Required';
        }
        if (q.type==='number') {
          const n = Number(v);
          if (v!==undefined && v!=='' && Number.isNaN(n)) errs[q.id]='Must be a number';
          if (q.min !== undefined && n < q.min) errs[q.id] = `Min ${q.min}`;
          if (q.max !== undefined && n > q.max) errs[q.id] = `Max ${q.max}`;
        }
        if ((q.type==='text' || q.type==='long') && q.maxLength && String(v||'').length > q.maxLength) {
          errs[q.id] = `Max length ${q.maxLength}`;
        }
      }
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function submit(e) {
    e.preventDefault();
    if (!validate()) return;
    onSubmit(values);
  }

  return (
    <div className="assessment-preview">
      <form onSubmit={submit}>
        {sections.map((s, i) => (
          <div key={s.id} className="mb-3">
            <h6>{s.title || `Section ${i+1}`}</h6>
            {s.questions.map((q) => isVisible(q) && (
              <div key={q.id} className="mb-2">
                <label className="form-label">{q.label || q.id} {q.required && <span className="text-danger">*</span>}</label>
                {q.type === 'single' && (
                  <select className="form-select" value={values[q.id] ?? ''} onChange={e=>setValues(v=>({ ...v, [q.id]: e.target.value }))}>
                    <option value="">Select...</option>
                    {q.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                )}
                {q.type === 'multi' && (
                  <div>
                    {(q.options||[]).map(opt => (
                      <div key={opt} className="form-check">
                        <input className="form-check-input" type="checkbox" checked={(values[q.id]||[]).includes(opt)} onChange={(e)=>{
                          const next = new Set(values[q.id]||[]);
                          if (e.target.checked) next.add(opt); else next.delete(opt);
                          setValues(v=>({ ...v, [q.id]: Array.from(next) }));
                        }} id={`${q.id}-${opt}`} />
                        <label className="form-check-label" htmlFor={`${q.id}-${opt}`}>{opt}</label>
                      </div>
                    ))}
                  </div>
                )}
                {(q.type === 'text' || q.type === 'long') && (
                  q.type === 'text'
                    ? <input className="form-control" value={values[q.id] ?? ''} onChange={e=>setValues(v=>({ ...v, [q.id]: e.target.value }))} />
                    : <textarea rows={3} className="form-control" value={values[q.id] ?? ''} onChange={e=>setValues(v=>({ ...v, [q.id]: e.target.value }))} />
                )}
                {q.type === 'number' && (
                  <input type="number" className="form-control" value={values[q.id] ?? ''} onChange={e=>setValues(v=>({ ...v, [q.id]: e.target.value }))} />
                )}
                {q.type === 'file' && (
                  <input type="file" className="form-control" onChange={e=>setValues(v=>({ ...v, [q.id]: e.target.files?.[0]?.name || '' }))} />
                )}
                {errors[q.id] && <div className="text-danger small">{errors[q.id]}</div>}
              </div>
            ))}
          </div>
        ))}
        <div className="d-flex justify-content-end"><Button type="submit">Submit assessment</Button></div>
      </form>
    </div>
  );
}

export default function AssessmentsPage() {
  const { jobId: jobIdStr } = useQuery();
  const [jobId, setJobId] = useState(jobIdStr || '');
  const [doc, setDoc] = useState(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!jobId) return;
    API.listAssessments(jobId).then(setDoc).catch(()=>setDoc(null));
  }, [jobId]);

  function addQuestion(sIndex) {
    const q = { id: crypto.randomUUID().slice(0,8), type:'text', label:'New question', required:false };
    const next = { ...doc, sections: doc.sections.map((s, i) => i===sIndex ? { ...s, questions: [...s.questions, q] } : s) };
    setDoc(next);
  }
  function updateQuestion(sIndex, qIndex, newQ) {
    const next = { ...doc };
    next.sections = next.sections.map((s,i) => {
      if (i !== sIndex) return s;
      const qs = s.questions.slice();
      qs[qIndex] = newQ;
      return { ...s, questions: qs };
    });
    setDoc(next);
  }
  function removeQuestion(sIndex, qIndex) {
    const next = { ...doc };
    next.sections = next.sections.map((s,i) => {
      if (i !== sIndex) return s;
      const qs = s.questions.slice();
      qs.splice(qIndex,1);
      return { ...s, questions: qs };
    });
    setDoc(next);
  }
  function addSection() {
    const section = { id: crypto.randomUUID().slice(0,8), title:`Section ${doc.sections.length+1}`, questions: [] };
    setDoc(d => ({ ...d, sections: [...d.sections, section] }));
  }

  async function save() {
    setSaving(true);
    setMessage('');
    try {
      await API.saveAssessment(Number(jobId), { sections: doc.sections });
      setMessage('Saved!');
    } catch(e) {
      setMessage('Save failed.');
    } finally {
      setSaving(false);
    }
  }

  async function submit(values) {
    setMessage('');
    try {
      await API.submitAssessment(Number(jobId), values);
      setMessage('Submitted!');
    } catch(e) {
      setMessage('Submit failed.');
    }
  }

  return (
    <div>
      <div className="page-header">
        <h3>Assessments</h3>
      </div>
      <div className="row g-2 mb-3">
        <div className="col-md-6">
          <InputGroup>
            <InputGroup.Text>Job ID</InputGroup.Text>
            <Form.Control placeholder="e.g., 1" value={jobId} onChange={e=>setJobId(e.target.value)} />
            <Button onClick={()=>API.listAssessments(jobId).then(setDoc).catch(()=>setDoc({ jobId:Number(jobId), sections:[] }))}>Load</Button>
          </InputGroup>
          <div className="form-text">Use from Job detail page to prefill ?jobId=</div>
        </div>
      </div>

      {!jobId && <div className="alert alert-info">Enter a Job ID to load/create its assessment.</div>}
      {jobId && !doc && <div>Loading...</div>}
      {doc && (
        <div className="assessment-builder">
          <div>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h6>Builder</h6>
              <div className="d-flex gap-2">
                <Button onClick={addSection} size="sm" variant="outline-secondary">Add Section</Button>
                <Button onClick={save} size="sm" disabled={saving}>{saving ? 'Saving...' : 'Save'}</Button>
              </div>
            </div>
            {doc.sections.map((s, sIndex) => (
              <div key={s.id} className="mb-3">
                <InputGroup className="mb-2">
                  <InputGroup.Text>Section title</InputGroup.Text>
                  <Form.Control value={s.title} onChange={e=>setDoc(d=>({ ...d, sections: d.sections.map((x,i)=> i===sIndex? { ...x, title:e.target.value } : x) }))} />
                </InputGroup>
                <div>
                  {s.questions.map((q, qIndex) => (
                    <QuestionEditor
                      key={q.id}
                      q={q}
                      index={qIndex}
                      allQuestions={s.questions}
                      onChange={(newQ) => updateQuestion(sIndex, qIndex, newQ)}
                      onRemove={() => removeQuestion(sIndex, qIndex)}
                    />
                  ))}
                </div>
                <Button size="sm" onClick={()=>addQuestion(sIndex)}>Add Question</Button>
              </div>
            ))}
          </div>

          <div>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h6>Live Preview</h6>
              <div className="text-muted small">{message}</div>
            </div>
            <AssessmentPreview sections={doc.sections} onSubmit={submit} />
          </div>
        </div>
      )}
    </div>
  );
}
