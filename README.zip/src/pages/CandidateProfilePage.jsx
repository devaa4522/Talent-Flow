import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api/client';
import { Form, Button } from 'react-bootstrap';
import { mentionUsers, extractMentions } from '../utils/mentions';

export default function CandidateProfilePage() {
  const { id } = useParams();
  const [candidate, setCandidate] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [note, setNote] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    API.getCandidate(id).then(setCandidate);
    API.getCandidateTimeline(id).then(setTimeline);
  }, [id]);

  function handleChange(e) {
    const v = e.target.value;
    setNote(v);
    const atIndex = v.lastIndexOf('@');
    if (atIndex >= 0) {
      const q = v.slice(atIndex+1).toLowerCase();
      const sug = mentionUsers.filter(u => u.name.toLowerCase().startsWith(q)).slice(0,5);
      setSuggestions(sug);
    } else {
      setSuggestions([]);
    }
  }
  function pickSuggestion(name) {
    const atIndex = note.lastIndexOf('@');
    const next = note.slice(0, atIndex+1) + name + ' ' + note.slice(atIndex+1);
    setNote(next);
    setSuggestions([]);
  }
  function addNote(e) {
    e.preventDefault();
    const mentions = extractMentions(note);
    setTimeline(tl => [...tl, { at: new Date().toISOString(), from: candidate.stage, to: candidate.stage, note, mentions }]);
    setNote('');
  }

  if (!candidate) return <div>Loading...</div>;

  return (
    <div>
      <div className="page-header">
        <h3>{candidate.name}</h3>
        <div className="text-muted">{candidate.email}</div>
      </div>
      <h6>Timeline</h6>
      <ul className="list-group mb-3">
        {timeline.map((ev, idx) => (
          <li key={idx} className="list-group-item">
            <div className="d-flex justify-content-between">
              <div><strong>{ev.from}</strong> → <strong>{ev.to}</strong></div>
              <div className="text-muted small">{new Date(ev.at).toLocaleString()}</div>
            </div>
            {ev.note && <div className="mt-1">{ev.note}</div>}
            {ev.mentions?.length > 0 && <div className="mention-hint">Mentions: {ev.mentions.join(', ')}</div>}
          </li>
        ))}
      </ul>

      <form onSubmit={addNote} className="mb-3">
        <Form.Label>Add note with @mentions</Form.Label>
        <Form.Control as="textarea" rows={3} value={note} onChange={handleChange} placeholder="e.g., @HR Team please screen this candidate" />
        {suggestions.length > 0 && (
          <div className="border rounded p-2 bg-white">
            {suggestions.map(s => <Button key={s.id} size="sm" variant="light" className="me-2 mb-1" onClick={()=>pickSuggestion(s.name)}>@{s.name}</Button>)}
          </div>
        )}
        <div className="mt-2 d-flex gap-2">
          <Button type="submit" variant="primary">Add Note</Button>
        </div>
      </form>
    </div>
  );
}
