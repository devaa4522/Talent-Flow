import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api/client';
import { Form, Button } from 'react-bootstrap';
import { mentionUsers, extractMentions } from '../utils/mentions';

const TalentflowPage = () => {
    const { id } = useParams();
    const [candidate, setCandidate] = useState(null);
    const [notes, setNotes] = useState([]);

    useEffect(() => {
        API.getCandidate(id).then(setCandidate);
        API.getCandidateTimeline(id).then(setNotes);
    }, [id]);

    if (!candidate) return null;

    function addNote(e) {
        e.preventDefault();
        const mentions = extractMentions(note);
        setNotes(notes => [...notes, { at: new Date().toISOString(), from: candidate.stage, to: candidate.stage, note, mentions }]);
        setNote('');
    }

    const [note, setNote] = useState('');
    const [suggestions, setSuggestions] = useState([]);  
    function handleChange(e) {
        const v = e.target.value;
        setNote(v);
        const atIndex = v.lastIndexOf('@');
        if (atIndex >= 0) {
            const q = v.slice(atIndex+1).toLowerCase();
            const sug = mentionUsers.filter(u => u.name.toLowerCase().startsWith(q)).slice(0,5);
            setSuggestions(sug);
        } else {
            setSuggestions([]);
        }
    }    
    function pickSuggestion(name) {
        const atIndex = note.lastIndexOf('@');
        const next = note.slice(0, atIndex+1) + name + ' ' + note.slice(atIndex+1);
        setNote(next);
        setSuggestions([]);
    }    

    return (
        <>
            <h1>{candidate.name} ({candidate.stage})</h1>
            <Form onSubmit={addNote}>
                <Form.Group>
                    <Form.Control type="text" value={note} onChange={handleChange} />
                    <Button type="submit">Add note</Button>
                </Form.Group>
            </Form>
            <ul>
                {notes.map((n,i) => <li key={i}>{n.note}</li>)}
            </ul>
        </>
    );
};