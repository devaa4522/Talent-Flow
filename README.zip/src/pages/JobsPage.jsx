import React, { useEffect, useMemo, useState } from 'react';
import { Button, Badge, Form, Modal, Row, Col, Table, Pagination } from 'react-bootstrap';
import API from '../api/client';
import { slugify } from '../utils/slugify';
import { useNavigate } from 'react-router-dom';
import { DndContext, closestCenter } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

function SortableRow({ job, index, onClick, onToggleStatus }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: job.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    cursor: 'grab',
    background: '#fff'
  };
  return (
    <tr ref={setNodeRef} style={style} {...attributes} {...listeners} onDoubleClick={onClick}>
      <td className="nowrap">⋮⋮</td>
      <td>{job.title}</td>
      <td><Badge bg={job.status === 'active' ? 'success' : 'secondary'}>{job.status}</Badge></td>
      <td>
        <div className="tags">
          {job.tags?.map(t => <span className="tag" key={t}>{t}</span>)}
        </div>
      </td>
      <td className="text-muted">#{job.order}</td>
    </tr>
  );
}

export default function JobsPage() {
  const [query, setQuery] = useState({ search:'', status:'', tags:'', page:1, pageSize:10, sort:'order' });
  const [data, setData] = useState({ items:[], total:0, page:1, pageSize:10, totalPages:1 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const navigate = useNavigate();

  async function load() {
    setLoading(true);
    setError('');
    try {
      const res = await API.listJobs(query);
      setData(res);
    } catch(e) {
      setError(e.message || 'Error');
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, [JSON.stringify(query)]);

  function openCreate() { setEditing(null); setShowModal(true); }
  function openEdit(job) { setEditing(job); setShowModal(true); }
  async function handleSave(form) {
    try {
      if (editing) {
        const updated = await API.updateJob(editing.id, form);
      } else {
        await API.createJob(form);
      }
      setShowModal(false);
      load();
    } catch(e) { alert(e.message); }
  }

  // DnD reorder optimistic
  const [localItems, setLocalItems] = useState([]);
  useEffect(() => setLocalItems(data.items), [data.items]);

  async function onDragEnd(event) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = localItems.findIndex(i => i.id === active.id);
    const newIndex = localItems.findIndex(i => i.id === over.id);
    const moved = localItems[oldIndex];
    const optimistic = arrayMove(localItems, oldIndex, newIndex).map((j, idx) => ({ ...j, order: (query.page-1)*query.pageSize + idx }));
    setLocalItems(optimistic);
    try {
      await API.reorderJob(moved.id, moved.order, (query.page-1)*query.pageSize + newIndex);
      load();
    } catch(e) {
      alert('Reorder failed on server; rolling back.');
      setLocalItems(data.items); // rollback
    }
  }

  return (
    <div>
      <div className="page-header">
        <h3>Jobs</h3>
        <div>
          <Button variant="primary" onClick={openCreate}>New Job</Button>
        </div>
      </div>

      <Row className="g-2 mb-3">
        <Col md={4}><Form.Control placeholder="Search title..." value={query.search} onChange={e=>setQuery(q=>({ ...q, page:1, search:e.target.value }))} /></Col>
        <Col md={3}>
          <Form.Select value={query.status} onChange={(e)=>setQuery(q=>({ ...q, page:1, status:e.target.value }))}>
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="archived">Archived</option>
          </Form.Select>
        </Col>
        <Col md={3}>
          <Form.Select value={query.sort} onChange={(e)=>setQuery(q=>({ ...q, sort:e.target.value }))}>
            <option value="order">Order</option>
            <option value="title">Title</option>
          </Form.Select>
        </Col>
      </Row>

      {error && <div className="alert alert-danger">{error}</div>}
      <div className="table-responsive">
        <DndContext collisionDetection={closestCenter} onDragEnd={onDragEnd}>
          <SortableContext items={localItems.map(i=>i.id)} strategy={verticalListSortingStrategy}>
            <Table hover size="sm" className="bg-white">
              <thead>
                <tr><th style={{width:40}}></th><th>Title</th><th>Status</th><th>Tags</th><th>Order</th><th></th></tr>
              </thead>
              <tbody>
                {localItems.map((job, idx) => (
                  <SortableRow key={job.id} job={job} index={idx} onClick={()=>navigate(`/jobs/${job.id}`)} />
                ))}
                {loading && <tr><td colSpan={5}>Loading...</td></tr>}
              </tbody>
            </Table>
          </SortableContext>
        </DndContext>
      </div>

      <div className="d-flex justify-content-between align-items-center">
        <div className="text-muted small">Total: {data.total}</div>
        <Pagination className="mb-0">
          <Pagination.Prev disabled={data.page<=1} onClick={()=>setQuery(q=>({ ...q, page: q.page-1 }))} />
          <Pagination.Item active>{data.page}</Pagination.Item>
          <Pagination.Next disabled={data.page>=data.totalPages} onClick={()=>setQuery(q=>({ ...q, page: q.page+1 }))} />
        </Pagination>
      </div>

      {showModal && <JobModal show onHide={()=>setShowModal(false)} job={editing} onSave={handleSave} />}
    </div>
  );
}

function JobModal({ show, onHide, job, onSave }) {
  const [title, setTitle] = React.useState(job?.title || '');
  const [slug, setSlug] = React.useState(job?.slug || '');
  const [tags, setTags] = React.useState(job?.tags?.join(', ') || '');
  const [status, setStatus] = React.useState(job?.status || 'active');

  function submit(e) {
    e.preventDefault();
    if (!title.trim()) return alert('Title is required');
    const payload = {
      title: title.trim(),
      slug: slugify(slug || title),
      tags: tags.split(',').map(t=>t.trim()).filter(Boolean),
      status
    };
    onSave(payload);
  }

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton><Modal.Title>{job ? 'Edit Job' : 'New Job'}</Modal.Title></Modal.Header>
      <Modal.Body>
        <form onSubmit={submit}>
          <div className="mb-3">
            <label className="form-label">Title *</label>
            <input className="form-control" value={title} onChange={e=>setTitle(e.target.value)} required />
          </div>
          <div className="mb-3">
            <label className="form-label">Slug</label>
            <input className="form-control" value={slug} onChange={e=>setSlug(e.target.value)} />
            <div className="form-text">Must be unique.</div>
          </div>
          <div className="mb-3">
            <label className="form-label">Tags (comma-separated)</label>
            <input className="form-control" value={tags} onChange={e=>setTags(e.target.value)} />
          </div>
          <div className="mb-3">
            <label className="form-label">Status</label>
            <select className="form-select" value={status} onChange={e=>setStatus(e.target.value)}>
              <option value="active">Active</option>
              <option value="archived">Archived</option>
            </select>
          </div>
          <div className="d-flex justify-content-end gap-2">
            <Button variant="secondary" onClick={onHide}>Cancel</Button>
            <Button type="submit" variant="primary">{job ? 'Save' : 'Create'}</Button>
          </div>
        </form>
      </Modal.Body>
    </Modal>
  );
}
