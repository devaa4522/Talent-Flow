import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import API from '../api/client';
import { Badge, Button } from 'react-bootstrap';

export default function JobDetailPage() {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    API.getJob(jobId).then(setJob).catch(e=>setError(e.message)).finally(()=>setLoading(false));
  }, [jobId]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;
  if (!job) return <div>Not found</div>;

  return (
    <div>
      <div className="page-header">
        <h3>{job.title}</h3>
        <div className="tags">
          <Badge bg={job.status === 'active' ? 'success' : 'secondary'}>{job.status}</Badge>
          {job.tags?.map(t => <span className="tag" key={t}>{t}</span>)}
        </div>
      </div>
      <p><strong>Slug:</strong> {job.slug}</p>
      <p><strong>Order:</strong> {job.order}</p>
      <p className="text-muted">Deep link: <code>/jobs/{job.id}</code></p>
      <div className="d-flex gap-2">
        <Button as={Link} to={`/assessments?jobId=${job.id}`} variant="primary">Open Assessment Builder</Button>
        <Button as={Link} to="/jobs" variant="outline-secondary">Back to Jobs</Button>
      </div>
    </div>
  );
}
