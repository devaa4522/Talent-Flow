import React, { useEffect, useMemo, useState } from 'react';
import API from '../api/client';
import { FixedSizeList as List } from 'react-window';
import { Link } from 'react-router-dom';
import { DndContext, useDraggable, useDroppable } from '@dnd-kit/core';
import { Button, Badge, Form, Row, Col } from 'react-bootstrap';

const STAGES = ["applied","screen","tech","offer","hired","rejected"];

function CandidateRow({ data, index, style }) {
  const c = data.items[index];
  return (
    <div style={style} className="d-flex justify-content-between align-items-center px-2">
      <div className="truncate">
        <Link to={`/candidates/${c.id}`} className="text-decoration-none">{c.name}</Link>
        <div className="text-muted small">{c.email}</div>
      </div>
      <Badge bg="info" className="badge-stage">{c.stage}</Badge>
    </div>
  );
}

function KanbanColumn({ id, title, items, onDrop }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div className="kanban-col">
      <h6 className="d-flex justify-content-between">
        <span>{title}</span>
        <Badge bg="light" text="dark">{items.length}</Badge>
      </h6>
      <div ref={setNodeRef} className="kanban-dropzone" style={{ background: isOver ? '#eef7ff' : undefined }}>
        {items.map(c => <DraggableCandidate key={c.id} candidate={c} />)}
      </div>
    </div>
  );
}
function DraggableCandidate({ candidate }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({ id: `cand-${candidate.id}`, data: candidate });
  const style = { transform: transform ? `translate3d(${transform.x}px, ${transform.y}px, 0)` : undefined };
  return (
    <div ref={setNodeRef} {...attributes} {...listeners} className="candidate-card" style={style}>
      <div className="fw-semibold">{candidate.name}</div>
      <div className="text-muted small">{candidate.email}</div>
    </div>
  );
}

export default function CandidatesPage() {
  const [query, setQuery] = useState({ search:'', stage:'', page:1, pageSize:50 });
  const [data, setData] = useState({ items:[], total:0, page:1, pageSize:50, totalPages:1 });
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try { setData(await API.listCandidates(query)); } finally { setLoading(false); }
  }
  useEffect(()=>{ load(); }, [JSON.stringify(query)]);

  // Kanban data
  const [columns, setColumns] = useState({});
  useEffect(() => {
    const byStage = {};
    for (const s of STAGES) byStage[s] = [];
    for (const c of data.items) byStage[c.stage].push(c);
    setColumns(byStage);
  }, [data.items]);

  async function onDragEnd(evt) {
    const drag = evt.active;
    const drop = evt.over;
    if (!drag || !drop) return;
    const cand = drag.data.current;
    const targetStage = drop.id;
    if (cand.stage === targetStage) return;
    // optimistic move
    setColumns(cols => {
      const next = { ...cols };
      next[cand.stage] = next[cand.stage].filter(x => x.id !== cand.id);
      next[targetStage] = [ { ...cand, stage: targetStage }, ...next[targetStage] ];
      return next;
    });
    try {
      await API.updateCandidate(cand.id, { stage: targetStage });
    } catch(err) {
      alert('Stage update failed; rolling back.');
      setColumns(cols => {
        const next = { ...cols };
        next[targetStage] = next[targetStage].filter(x => x.id !== cand.id);
        next[cand.stage] = [ cand, ...next[cand.stage] ];
        return next;
      });
    }
  }

  return (
    <div>
      <div className="page-header">
        <h3>Candidates</h3>
      </div>
      <Row className="g-2 mb-3">
        <Col md={5}><Form.Control placeholder="Search name/email..." value={query.search} onChange={e=>setQuery(q=>({ ...q, page:1, search:e.target.value }))} /></Col>
        <Col md={3}>
          <Form.Select value={query.stage} onChange={e=>setQuery(q=>({ ...q, page:1, stage:e.target.value }))}>
            <option value="">All stages</option>
            {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
          </Form.Select>
        </Col>
      </Row>

      <div className="mb-4">
        <div className="border rounded bg-white" style={{ height: 360, overflow: 'hidden' }}>
          <List height={360} itemCount={data.items.length} itemSize={56} width={'100%'} itemData={data}>
            {CandidateRow}
          </List>
        </div>
        {loading && <div className="text-muted small mt-2">Loading...</div>}
      </div>

      <h5 className="mb-2">Pipeline (drag candidates between stages)</h5>
      <DndContext onDragEnd={onDragEnd}>
        <div className="kanban">
          {STAGES.map(s => <KanbanColumn key={s} id={s} title={s.toUpperCase()} items={columns[s] || []} />)}
        </div>
      </DndContext>
    </div>
  );
}
