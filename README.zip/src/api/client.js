const API = {
  async listJobs(params = {}) {
    const url = new URL('/jobs', window.location.origin);
    Object.entries(params).forEach(([k,v]) => v !== undefined && v !== null && v !== '' && url.searchParams.set(k, v));
    const res = await fetch(url, { headers: { 'Accept': 'application/json' }});
    if (!res.ok) throw new Error('Failed to fetch jobs');
    return res.json();
  },
  async createJob(payload) {
    const res = await fetch('/jobs', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(payload) });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  async updateJob(id, patch) {
    const res = await fetch(`/jobs/${id}`, { method:'PATCH', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(patch) });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  async reorderJob(id, fromOrder, toOrder) {
    const res = await fetch(`/jobs/${id}/reorder`, { method:'PATCH', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ fromOrder, toOrder }) });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  async getJob(id) {
    const res = await fetch(`/jobs/${id}`, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) throw new Error('Job not found');
    return res.json();
  },
  async listCandidates(params={}) {
    const url = new URL('/candidates', window.location.origin);
    Object.entries(params).forEach(([k,v]) => v !== undefined && v !== null && v !== '' && url.searchParams.set(k, v));
    const res = await fetch(url, { headers:{ 'Accept':'application/json' } });
    if (!res.ok) throw new Error('Failed to fetch candidates');
    return res.json();
  },
  async getCandidate(id) {
    const res = await fetch(`/candidates/${id}`, { headers:{ 'Accept':'application/json' } });
    if (!res.ok) throw new Error('Not found');
    return res.json();
  },
  async updateCandidate(id, patch) {
    const res = await fetch(`/candidates/${id}`, { method:'PATCH', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(patch) });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  },
  async getCandidateTimeline(id) {
    const res = await fetch(`/candidates/${id}/timeline`, { headers:{ 'Accept':'application/json' } });
    if (!res.ok) throw new Error('Failed timeline');
    return res.json();
  },
  async listAssessments(jobId) {
    const res = await fetch(`/assessments/${jobId}`, { headers:{ 'Accept': 'application/json' } });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error('Failed');
    return res.json();
  },
  async saveAssessment(jobId, payload) {
    const res = await fetch(`/assessments/${jobId}`, { method:'PUT', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(payload) });
    if (!res.ok) throw new Error('Failed');
    return res.json();
  },
  async submitAssessment(jobId, answers) {
    const res = await fetch(`/assessments/${jobId}/submit`, { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(answers) });
    if (!res.ok) throw new Error('Failed');
    return res.json();
  },
};
export default API;
